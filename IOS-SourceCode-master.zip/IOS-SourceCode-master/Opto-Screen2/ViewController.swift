//
//  ViewController.swift
//  Opto-Screen2
//
//  Created by apple on 9/18/21.
//
// fixed the app crashing for too much zoom in image by Jaspreet Singh
//

import UIKit
import CoreImage
import CoreGraphics.CGImage
import CoreGraphics.CGBase
import ImageCoordinateSpace

class ViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate, UIGestureRecognizerDelegate {
    
    @IBOutlet var scrollView: UIScrollView!
    
    @IBOutlet var labelPatientName: UILabel!
    @IBOutlet var labelTime: UILabel!
    @IBOutlet var labelStatus: UILabel!
    
    @IBOutlet var labelPixelColor: UILabel!
    @IBOutlet var labelPixelCount: UILabel!
    @IBOutlet var labelCPoint: UILabel!
    @IBOutlet var labelCounter: UILabel!
    @IBOutlet var labelCenterR: UILabel!
    @IBOutlet var labelCenterG: UILabel!
    @IBOutlet var labelCenterB: UILabel!
    @IBOutlet var labelXMax: UILabel!
    @IBOutlet var labelXMin: UILabel!
    @IBOutlet var labelYMax: UILabel!
    @IBOutlet var labelYMin: UILabel!
    @IBOutlet var labelRadius: UILabel!
    
    @IBOutlet var sliderIris: UISlider!
    @IBOutlet var sliderContrast: UISlider!
    
    @IBOutlet var imageViewEye: UIImageView!
    
    @IBOutlet var selectPatientBtn: UIButton!
    
    var objectSize:CGFloat = 150
    var newSize:CGFloat = 150
    
    var eyePixelObject: EyePixelObjectView = {
        let view = EyePixelObjectView(frame: CGRect(origin: .zero, size: CGSize(width: 150, height: 150)))
        return view
    }()
    var panGesture: UIPanGestureRecognizer!
    var trayOriginalCenter: CGPoint!
    
    var zoomValue: Float = 1.0
    var contrastValue: Float = 2.5
    var eyeImage: UIImage!
    var croppedImage: UIImage!
    var context: CIContext!
    var currentFilter: CIFilter!
    
    var patients: [String] = []
    var patientPhotos: [String] = []
    let transparentView = UIView()
    var tableView = UITableView()
    var dataSource = [String]()
    var patientName: UITextField?
    var dateOfBirth: UITextField?
    var currentPatient: String? = nil
    var currentPhoto: String? = nil
    var selecting: String?
    var selectedButton = UIButton()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupPatient()
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(CellView.self, forCellReuseIdentifier: "Cell")
        
        context = CIContext()
        currentFilter = nil
        
        sliderIris.value = 0.5
        sliderContrast.value = 0.5
        sliderContrast.isHidden = true
        
        view.addSubview(eyePixelObject)
        
        eyePixelObject.center = imageViewEye.center
        
        panGesture = UIPanGestureRecognizer(target: self, action: #selector(didPanTray(_:)))
        panGesture.delegate = self
        eyePixelObject.addGestureRecognizer(panGesture)
        
        eyePixelObject.isMultipleTouchEnabled = true
        eyePixelObject.isUserInteractionEnabled = true
        
        zoomValue = sliderIris.value
        eyePixelObject.transform = CGAffineTransform(scaleX: CGFloat(zoomValue), y: CGFloat(zoomValue))
    }
    
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        return true
    }
    
    @objc func didPanTray(_ sender: UIPanGestureRecognizer) {
        let center = self.imageViewEye.center
        
        switch sender.state {
        case .began:
            trayOriginalCenter = eyePixelObject.center
        case .changed:
            let translation = sender.translation(in: view)
            
            let point = CGPoint(x: trayOriginalCenter.x + translation.x - (newSize/2), y: trayOriginalCenter.y + translation.y - (newSize/2))
            if imageViewEye.frame.contains(point) {
                eyePixelObject.center = CGPoint(x: trayOriginalCenter.x + translation.x, y: trayOriginalCenter.y + translation.y)
            } else {
                eyePixelObject.center = center
            }
        case .ended:
            let translation = sender.translation(in: view)
            
            let point = CGPoint(x: trayOriginalCenter.x + translation.x - (newSize/2), y: trayOriginalCenter.y + translation.y - (newSize/2))
            if imageViewEye.frame.contains(point) {
                eyePixelObject.center = CGPoint(x: trayOriginalCenter.x + translation.x, y: trayOriginalCenter.y + translation.y)
            } else {
                eyePixelObject.center = center
            }
        default:
            break
        }
    }
    
    func setupPatient() {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentsDirectory = paths[0]
        let docURL = URL(string: documentsDirectory)!
        let dataPath = docURL.appendingPathComponent("Patients")
        if !FileManager.default.fileExists(atPath: dataPath.absoluteString) {
            do {
                try FileManager.default.createDirectory(atPath: dataPath.absoluteString, withIntermediateDirectories: true, attributes: nil)
            } catch {
                print(error.localizedDescription)
            }
        }
        
        do {
            let directoryContents = try FileManager.default.contentsOfDirectory(at: dataPath.absoluteURL, includingPropertiesForKeys: nil, options: [])
            for item in directoryContents {
                if (item.lastPathComponent != ".DS_Store"){
                    patients.append(item.lastPathComponent)
                }
            }
        }
        catch {
            print(error.localizedDescription)
        }
        patients.append("Create Patient")
        patients.append("Cancel")
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
    }
    
    @IBAction func sliderIrisAction(_ sender: UISlider) {
        zoomValue = sliderIris.value
        newSize = objectSize * CGFloat(sliderIris.value)
        eyePixelObject.transform = CGAffineTransform(scaleX: CGFloat(zoomValue), y: CGFloat(zoomValue))
    }
    
    @IBAction func sliderContrastAction(_ sender: UISlider) {
        contrastValue = sliderContrast.value * 5
        applyProcessing()
    }
    
    @IBAction func btnContrast(_ sender: UIButton) {
        if currentFilter != nil && imageViewEye.image != nil {
            sliderContrast.isHidden = !sliderContrast.isHidden
        } else if imageViewEye.image == nil {
            showAlert(message: "Please add Image first using Select Button.")
        } else {
            showAlert(message: "Please apply a filter to the image to change contrast value.")
        }
    }
    
    @IBAction func btnSelectPatient(_ sender: UIButton) {
        selecting = "Patient"
        readPatientsDir()
        dataSource = patients
        selectedButton = selectPatientBtn
        addTransparentView(frames: selectPatientBtn.frame, withTap: true)
    }
    
    func readPatientsDir() {
        patients.removeAll()
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentsDirectory = paths[0]
        let docURL = URL(string: documentsDirectory)!
        let dataPath = docURL.appendingPathComponent("Patients")
        do {
            let directoryContents = try FileManager.default.contentsOfDirectory(at: dataPath.absoluteURL, includingPropertiesForKeys: nil, options: [])
            for item in directoryContents {
                if (item.lastPathComponent != ".DS_Store"){
                    print(item.lastPathComponent)
                    patients.append(item.lastPathComponent)
                }
            }
        }
        catch {
            print(error.localizedDescription)
        }
        patients.append("Create Patient")
        patients.append("Cancel")
    }
    
    func addTransparentView(frames: CGRect, withTap: Bool) {
        let screenSize = UIScreen.main.bounds
        let screenHeight = screenSize.height
        let screenWidth = screenSize.width
        let window = UIApplication.shared.keyWindow
        transparentView.frame = window?.frame ?? self.view.frame
        self.view.addSubview(transparentView)
        
        tableView.frame = CGRect(x: 10, y: 150 , width: screenWidth - 20,  height: 0)
        
        self.view.addSubview(tableView)
        tableView.layer.cornerRadius = 5
        
        transparentView.backgroundColor = UIColor.black.withAlphaComponent(0.9)
        
        tableView.reloadData()
        if(withTap){
            let tapgesture = UITapGestureRecognizer(target: self, action: #selector(removeTransparentView))
            transparentView.addGestureRecognizer(tapgesture)
        }
        transparentView.alpha = 0
        UIView.animate(withDuration: 0.4, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: .curveEaseInOut, animations: {
            self.transparentView.alpha = 0.5
            self.tableView.frame = CGRect(x: 10, y: 150 , width: screenWidth - 20, height: screenHeight - 150)
        }, completion: nil)
    }
    
    @objc func removeTransparentView() {
        let screenSize = UIScreen.main.bounds
        let screenWidth = screenSize.width
        UIView.animate(withDuration: 0.4, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: .curveEaseInOut, animations: {
            self.transparentView.alpha = 0.0
            self.tableView.frame = CGRect(x: 10, y: 150 , width: screenWidth - 20, height: 0)
        }, completion: nil)
    }
    
    @IBAction func btnExport(_ sender: UIButton) {
        if currentPatient != nil {
            let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
            let documentsDirectory = paths[0]
            let docURL = URL(string: documentsDirectory)!
            let dataPath = docURL.appendingPathComponent("Patients").appendingPathComponent(currentPatient ?? "")
            var dataString: String = dataPath.absoluteString
            dataString = ("file://" + dataString)
            compress(dataString: dataString)
        } else {
            showAlert(message: "Please select a patient")
        }
    }
    
    func compress(dataString: String) {
        let fm = FileManager.default
        let baseDirectoryUrl = URL(string: dataString)!
        
        var archiveUrl: URL?
        var error: NSError?
        
        let coordinator = NSFileCoordinator()
        coordinator.coordinate(readingItemAt: baseDirectoryUrl, options: [.forUploading], error: &error) { (zipUrl) in
            let path = (currentPatient ?? "archive") + ".zip"
            let tmpUrl = try! fm.url(
                for: .itemReplacementDirectory,
                   in: .userDomainMask,
                   appropriateFor: zipUrl,
                   create: true
            ).appendingPathComponent(path)
            try! fm.moveItem(at: zipUrl, to: tmpUrl)
            archiveUrl = tmpUrl
        }
        
        if let archiveUrl = archiveUrl {
            let avc = UIActivityViewController(activityItems: [archiveUrl], applicationActivities: nil)
            present(avc, animated: true)
        } else {
            print(error ?? "none")
        }
    }
    
    @IBAction func btnDelete(_ sender: UIButton) {
        displayDeleteAction()
    }
    
    func displayDeleteAction() {
        let alertText = "WARNING: you are about to delete all photos and records of \"" + (currentPatient ?? "None selected") + "\" this action cannot be undone, press \"Cancel\" to cancel this action, press \"Confirm\" to confirm deletion."
        let alertController = UIAlertController(title: alertText, message: nil, preferredStyle: .alert)
        
        let okAction = UIAlertAction(title: "Confirm", style: .default, handler: self.confirmDeleteHandler)
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true)
    }
    
    func confirmDeleteHandler(alert: UIAlertAction!) {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentsDirectory = paths[0]
        let docURL = URL(string: documentsDirectory)!
        let dataPath = docURL.appendingPathComponent("Patients").appendingPathComponent(currentPatient ?? "")
        let dataString: String = dataPath.absoluteString
        let finalURL = URL(string: ("file://" + dataString))
        let fileManager = FileManager.default
        do{
            try fileManager.removeItem(at: finalURL!)
        } catch {
            print(error)
        }
        clearDash(withPatient: true)
    }
    
    @IBAction func btnCalculate(_ sender: UIButton) {
        if(imageViewEye.image != nil) {
            let currentDateTime = Date()
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "yyy-MM-dd HH:mm:ss"
            self.labelTime.text = "\(dateFormatter.string(from: currentDateTime))"
            
            let xMin = Int(self.imageViewEye.frame.minX + self.eyePixelObject.frame.minX)
            let xMax = Int(self.imageViewEye.frame.minX + self.eyePixelObject.frame.maxX)
            let yMin = Int(self.imageViewEye.frame.minY + self.eyePixelObject.frame.minY)
            let yMax = Int(self.imageViewEye.frame.minY + self.eyePixelObject.frame.maxY)
            
            let radius = Int(self.eyePixelObject.frame.size.width / 2)
            
            self.labelXMax.text = "XMax: \(xMax)"
            self.labelXMin.text = "XMin: \(xMin)"
            self.labelYMax.text = "YMax: \(yMax)"
            self.labelYMin.text = "YMin: \(yMin)"
            self.labelRadius.text = "Radius: \(radius)"
            
            let xCenter = xMin + radius
            let yCenter = yMin + radius
            
            let circle1 = UIBezierPath(arcCenter: CGPoint(x: xCenter, y: yCenter), radius: CGFloat(radius), startAngle: CGFloat(0), endAngle: CGFloat(Double.pi * 2), clockwise: true)
            
            let centerPoint = CGPoint(x: xCenter, y: yCenter)
            let imgEye = self.imageViewEye.image!
            let centerPixel = CGPoint(x: imageViewEye.bounds.minX + eyePixelObject.frame.midX, y: imageViewEye.bounds.minY + eyePixelObject.frame.midY)
            let imageSpace = imageViewEye.contentSpace()
            let imgPoints = imageSpace.convert(centerPixel, to: imageViewEye)
            
            let centerColor = imgEye.pixelColor(x: imgPoints.x, y: imgPoints.y)
            
            let centerR = CGFloat(centerColor.rgba.red) * 255
            self.labelCenterR.text = "CenterR: \(centerR)"
            let centerG = CGFloat(centerColor.rgba.green) * 255
            self.labelCenterG.text = "CenterG: \(centerG)"
            let centerB = CGFloat(centerColor.rgba.blue) * 255
            self.labelCenterB.text = "CenterB: \(centerB)"
            
            self.labelCPoint.text = "CPoint: \(centerPoint)"
            
            var x: Float = 0
            var i: Float = 0
            var o = 0
            var countCirclePixels: Float = 1.0
            
            while x < 400 {
                let pos = CGPoint(x: Int.random(in: xMin...xMax), y: Int.random(in: yMin...yMax))
                let imgPos = self.view.convert(pos, to: imageViewEye)
                let pixelColor = imgEye.pixelColor(x: imgPos.x, y: imgPos.y)
                
                var pixelRed: CGFloat = 0.0
                var pixelGreen: CGFloat = 0.0
                var pixelBlue: CGFloat = 0.0
                
                pixelRed = (pixelColor.rgba.red)
                pixelGreen = (pixelColor.rgba.green)
                pixelBlue = (pixelColor.rgba.blue)
                
                if circle1.contains(pos) {
                    countCirclePixels += 1.0
                }
                
                if circle1.contains(pos) && (pixelRed + pixelGreen + pixelBlue <= 1.4 * (centerR + centerG + centerB)) {
                    i += 1
                } else {
                    o += 1
                }
                
                x += 1
                
                let ratio = 4 * (i/x)
                let circleCounterRatio = (countCirclePixels / 400) * 4
                
                if Double(ratio) > Double.pi {
                    self.labelPixelColor.text = "\(Double.pi)"
                } else {
                    self.labelPixelColor.text = "\(ratio)"
                }
                
                if Double(circleCounterRatio) > Double.pi {
                    self.labelPixelCount.text = "\(Double.pi)"
                } else {
                    self.labelPixelCount.text = "\(circleCounterRatio)"
                }
            }
            self.labelCounter.text = "Counter: \(countCirclePixels)"
            
            
            let imageData = imageViewEye.image!
            let name = String(String(NSDate().timeIntervalSince1970).split(separator: ".")[0]) + ".png"
            saveImageToData(imageName: name, data: imageData)
            
            let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
            let documentsDirectory = paths[0]
            let docURL = URL(string: documentsDirectory)!
            let dataPath = docURL.appendingPathComponent("Patients").appendingPathComponent(currentPatient!)
            let pathString = dataPath.appendingPathComponent(currentPatient! + ".csv").path.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed)!
            let path = URL(string: ("file://" + pathString))
            let text = "\(name), \(dateFormatter.string(from: currentDateTime)), \(centerPoint), \(countCirclePixels), \(centerR), \(centerG), \(centerB), \(xMax), \(xMin), \(yMax), \(yMin), \(radius)" + "\n"
            do{
                try text.appendToURL(fileURL: path!)
            } catch {
                print(error.localizedDescription)
            }
        } else {
            showAlert(message: "Please select a Patient & a Photo")
        }
    }
    
    func saveImageToData(imageName: String, data: UIImage) {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentsDirectory = paths[0]
        let docURL = URL(fileURLWithPath: documentsDirectory)
        let dataPath = docURL.appendingPathComponent("Patients").appendingPathComponent(currentPatient!).appendingPathComponent(imageName)
        do {
            try data.pngData()?.write(to: dataPath, options: .atomic)
        } catch {
            print(error.localizedDescription)
        }
    }
    
    @IBAction func btnSelectPic(_ sender: UIButton) {
        if currentPatient != nil {
            clearDash(withPatient: false)
            let alert = UIAlertController(title: "Select Image From", message: nil, preferredStyle: .actionSheet)
            let cameraAction = UIAlertAction(title: "Camera", style: .default) { _ in
                let imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = .camera
                imagePicker.allowsEditing = false
                self.imageViewEye.image = nil
                self.present(imagePicker, animated: true, completion: nil)
            }
            let imageLibAction = UIAlertAction(title: "Photo Library", style: .default) { _ in
                let imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = .photoLibrary
                imagePicker.allowsEditing = false
                self.imageViewEye.image = nil
                self.present(imagePicker, animated: true, completion: nil)
            }
            alert.addAction(cameraAction)
            alert.addAction(imageLibAction)
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
            self.present(alert, animated: true)
        } else {
            showAlert(message: "Please Select a Patient")
        }
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        guard let image = info[.originalImage] as? UIImage else { return }
        self.eyeImage = image
        dismiss(animated: true) {
            self.performSegue(withIdentifier: "cropViewSegue", sender: self)
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "cropViewSegue" {
            let vc = segue.destination as! CropperViewController
            vc.image = eyeImage
            vc.delegate = self
        }
    }
    
    @IBAction func switchAction(_ sender: UISwitch) {
        if sender.isOn {
            labelStatus.text = "ABNORMAL"
            labelPixelCount.isHidden = true;
        }
        else {
            labelStatus.text = "NORMAL"
            labelPixelCount.isHidden = false;
        }
    }
    
    @IBAction func btnFilters(_ sender: UIButton) {
        if(imageViewEye.image != nil) {
            let alert = UIAlertController(title: "Choose filter", message: nil, preferredStyle: .actionSheet)
            alert.addAction(UIAlertAction(title: "Exposure", style: .default, handler: setFilter))
            alert.addAction(UIAlertAction(title: "Blur", style: .default, handler: setFilter))
            alert.addAction(UIAlertAction(title: "Sepia", style: .default, handler: setFilter))
            alert.addAction(UIAlertAction(title: "Sharpness", style: .default, handler: setFilter))
            alert.addAction(UIAlertAction(title: "Negative", style: .default, handler: setFilter))
            alert.addAction(UIAlertAction(title: "Remove Filter", style: .destructive, handler: setFilter))
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel))
            present(alert, animated: true)
        } else {
            showAlert(message: "Please select a Patient & a Photo")
        }
    }
}


extension ViewController: CropperViewControllerDelegate {
    func croppedImage(image: UIImage) {
        croppedImage = image
        guard context != nil else { return }
        currentFilter = CIFilter(name: "CIToneCurve")
        let cgImg = CIImage(image: image)
        
        if currentFilter != nil {
            currentFilter.setValue(cgImg, forKey: kCIInputImageKey)
        }
        applyProcessing()
    }
    
    func setFilter(action: UIAlertAction) {
        guard context != nil else { return }
        
        if action.title == "Blur" {
            currentFilter = CIFilter(name: "CIGaussianBlur")
        } else if action.title == "Sepia" {
            currentFilter = CIFilter(name: "CISepiaTone")
        } else if action.title == "Sharpness" {
            currentFilter = CIFilter(name: "CIUnsharpMask")
        } else if action.title == "Negative" {
            currentFilter = CIFilter(name: "CIColorInvert")
        } else if action.title == "Exposure" {
            currentFilter = CIFilter(name: "CIExposureAdjust")
        } else if action.title == "Remove Filter" {
            currentFilter = CIFilter(name: "CIToneCurve")
        }
        
        guard let image = croppedImage else { return }
        let cgImg = CIImage(image: image)
        
        if currentFilter != nil {
            currentFilter.setValue(cgImg, forKey: kCIInputImageKey)
        }
        applyProcessing()
    }
    
    func applyProcessing() {
        if currentFilter == nil {
            self.imageViewEye.image = croppedImage
            self.sliderContrast.isHidden = true
        } else {
            let inputKeys = currentFilter.inputKeys
            if inputKeys.contains(kCIInputIntensityKey) { currentFilter.setValue(contrastValue, forKey: kCIInputIntensityKey)}
            if inputKeys.contains(kCIInputRadiusKey) { currentFilter.setValue(contrastValue * 200, forKey: kCIInputRadiusKey) }
            if inputKeys.contains(kCIInputScaleKey) { currentFilter.setValue(contrastValue * 10, forKey: kCIInputScaleKey) }
            if inputKeys.contains(kCIInputCenterKey) { currentFilter.setValue(CIVector(x: eyeImage.size.width / 2, y: eyeImage.size.height / 2), forKey: kCIInputCenterKey) }
            if inputKeys.contains(kCIInputEVKey) { currentFilter.setValue(contrastValue/4, forKey: kCIInputEVKey) }
            
            if let outputImage = currentFilter.outputImage,
               let cgImg = context.createCGImage(outputImage, from: outputImage.extent) {
                let processedImage = UIImage(cgImage: cgImg)
                self.imageViewEye.image = processedImage
            }
        }
    }
    
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Warning", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
}

extension ViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = dataSource[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let selected = dataSource[indexPath.row]
        if(selecting == "Patient") {
            if selected == "Create Patient" {
                displayAlertAction()
            } else if selected == "Cancel" {
            } else {
                setCurrentPatient(patient: selected)
            }
        } else if selecting == "Photo" {
            if selected == "Cancel" {
            } else {
                setImageView(photoPath: selected)
                currentPhoto = selected
            }
        }
        removeTransparentView()
    }
    
    func displayAlertAction() {
        let alertController = UIAlertController(title: "New Patient", message: nil, preferredStyle: .alert)
        alertController.addTextField(configurationHandler: patientName)
        alertController.addTextField(configurationHandler: dateOfBirth)
        
        let okAction = UIAlertAction(title: "Confirm", style: .default, handler: self.confirmHandler)
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel, handler: nil)
        alertController.addAction(okAction)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true)
    }
    
    func patientName(textField: UITextField!) {
        patientName = textField
        patientName?.placeholder = "First Last"
    }
    
    func dateOfBirth(textField: UITextField!) {
        dateOfBirth = textField
        dateOfBirth?.placeholder = "mm/dd/yyyy"
    }
    
    func confirmHandler(alert: UIAlertAction!) {
        if (patientName?.text != nil && patientName?.text != "") && (dateOfBirth?.text != nil && dateOfBirth?.text != "") {
            newPatient(patient: (patientName?.text)!, dob: (dateOfBirth?.text)!)
            setCurrentPatient(patient: (patientName?.text)!)
            readPatientsDir()
        } else {
            showAlert(message: "All Input Fields must be filled.")
        }
    }
    
    func newPatient(patient: String, dob: String) {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentsDirectory = paths[0]
        let docURL = URL(string: documentsDirectory)!
        let dataPath = docURL.appendingPathComponent("Patients").appendingPathComponent(patient)
        let absPath = dataPath.absoluteString.removingPercentEncoding
        let pathString = dataPath.appendingPathComponent(patient + ".csv").path
        let fileString = ("file://" + pathString.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed)!)
        let pathFinal = URL(string: fileString)
        let text = "Name, " + patient + ", DOB, " + dob + "\nFilename, Date/Time, CenterPoint-x, CenterPoint-y, Counter, CenterR, CenterG, CenterB, XMax, Xmin, YMax, YMin, Radius\n"
        
        if !FileManager.default.fileExists(atPath: absPath!) {
            do {
                try FileManager.default.createDirectory(atPath: absPath!, withIntermediateDirectories: true, attributes: nil)
            } catch {
                print(error.localizedDescription)
            }
        }
        do {
            try text.write(to: pathFinal!, atomically: false, encoding: .utf8)
        } catch {
            print(error.localizedDescription)
        }
    }
    
    func setCurrentPatient(patient: String) {
        labelPatientName.text = patient
        currentPatient = patient
    }
    
    func setImageView(photoPath: String) {
        let paths = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)
        let documentsDirectory = paths[0]
        let docURL = URL(string: documentsDirectory)!
        let dataPath = docURL.appendingPathComponent("Patients").appendingPathComponent(currentPatient ?? "")
        do {
            let directoryContents = try FileManager.default.contentsOfDirectory(at: dataPath.absoluteURL, includingPropertiesForKeys: nil, options: [])
            for item in directoryContents {
                if (item.lastPathComponent == photoPath){
                    let image = UIImage(contentsOfFile: item.path)
                    let cropperViewController = self.storyboard?.instantiateViewController(withIdentifier: "cropperViewController") as! CropperViewController
                    cropperViewController.image = image
                    cropperViewController.delegate = self
                    self.navigationController?.pushViewController(cropperViewController, animated: true)
                }
            }
        }
        catch {
            print(error.localizedDescription)
        }
    }
    
    func clearDash(withPatient: Bool) {
        imageViewEye.image = nil
        labelXMax.text = "XMax:"
        labelXMin.text = "XMin:"
        labelYMax.text = "YMax:"
        labelYMin.text = "YMin:"
        labelRadius.text = "Radius:"
        labelCPoint.text = "CPoint:"
        labelCounter.text = "Counter:"
        labelCenterR.text = "CenterR:"
        labelCenterG.text = "CenterG:"
        labelCenterB.text = "CenterB:"
        labelPixelColor.text = ""
        labelPixelCount.text = ""
        
        if withPatient {
            labelPatientName.text = "Patient"
            currentPatient = nil
        }
        currentPhoto = nil
    }
}

class CellView: UITableViewCell {
}

extension UIColor {
    var rgba: (red: CGFloat, green: CGFloat, blue: CGFloat, alpha: CGFloat) {
        var red: CGFloat = 0
        var green: CGFloat = 0
        var blue: CGFloat = 0
        var alpha: CGFloat = 0
        getRed(&red, green: &green, blue: &blue, alpha: &alpha)
        
        return (red, green, blue, alpha)
    }
    
    convenience init(red: UInt8, green: UInt8, blue: UInt8, alpha: UInt8) {
        self.init(
            red: CGFloat(red)/255,
            green: CGFloat(green)/255,
            blue: CGFloat(blue)/255,
            alpha: CGFloat(alpha)/255)
    }
}

extension String {
    func appendLineToURL(fileURL: URL) throws {
        try (self + "\n").appendToURL(fileURL: fileURL)
    }
    
    func appendToURL(fileURL: URL) throws {
        let data = self.data(using: String.Encoding.utf8)!
        try data.append(fileURL: fileURL)
    }
}

extension Data {
    func append(fileURL: URL) throws {
        if let fileHandle = FileHandle(forWritingAtPath: fileURL.path) {
            defer {
                fileHandle.closeFile()
            }
            fileHandle.seekToEndOfFile()
            fileHandle.write(self)
        }
        else {
            try write(to: fileURL, options: .atomic)
        }
    }
}

extension UIImage {
    
    var pixelWidth: Int {
        return cgImage?.width ?? 0
    }
    
    var pixelHeight: Int {
        return cgImage?.height ?? 0
    }
    //fixed function by Jaspreet Singh
    func pixelColor(x: CGFloat, y: CGFloat) -> UIColor {
        // Check if the coordinates are out of bounds
        guard
            0..<pixelWidth ~= Int(x) && 0..<pixelHeight ~= Int(y),
            let cgImage = cgImage,
            let data = cgImage.dataProvider?.data,
            let dataPtr = CFDataGetBytePtr(data),
            let colorSpaceModel = cgImage.colorSpace?.model,
            let componentLayout = cgImage.bitmapInfo.componentLayout
        else {
            // Coordinates are out of bounds or other issues, return default color
            return .clear
        }

        assert(
            colorSpaceModel == .rgb,
            "The only supported color space model is RGB")
        assert(
            cgImage.bitsPerPixel == 32 || cgImage.bitsPerPixel == 24,
            "A pixel is expected to be either 4 or 3 bytes in size")

        let bytesPerRow = cgImage.bytesPerRow
        let bytesPerPixel = cgImage.bitsPerPixel/8
        let pixelOffset = Int(y)*bytesPerRow + Int(x)*bytesPerPixel

        if componentLayout.count == 4 {
            let components = (
                dataPtr[pixelOffset + 0],
                dataPtr[pixelOffset + 1],
                dataPtr[pixelOffset + 2],
                dataPtr[pixelOffset + 3]
            )

            var alpha: UInt8 = 0
            var red: UInt8 = 0
            var green: UInt8 = 0
            var blue: UInt8 = 0

            switch componentLayout {
            case .bgra:
                alpha = components.3
                red = components.2
                green = components.1
                blue = components.0
            // ... (rest of the switch cases remain unchanged)
            default:
                assertionFailure("Unsupported component layout")
                return .clear
            }

            if cgImage.bitmapInfo.chromaIsPremultipliedByAlpha && alpha != 0 {
                let invUnitAlpha = 255/CGFloat(alpha)
                red = UInt8((CGFloat(red)*invUnitAlpha).rounded())
                green = UInt8((CGFloat(green)*invUnitAlpha).rounded())
                blue = UInt8((CGFloat(blue)*invUnitAlpha).rounded())
            }

            return .init(red: red, green: green, blue: blue, alpha: alpha)

        } else if componentLayout.count == 3 {
            // ... (rest of the function for 3 components remains unchanged)
        } else {
            assertionFailure("Unsupported number of pixel components")
            return .clear
        }

        // Add a default return statement to satisfy compiler
        return .clear
    }

    /*func pixelColor(x: CGFloat, y: CGFloat) -> UIColor {
        assert(
            0..<pixelWidth ~= Int(x) && 0..<pixelHeight ~= Int(y),
            "Pixel coordinates are out of bounds")
        
        guard
            let cgImage = cgImage,
            let data = cgImage.dataProvider?.data,
            let dataPtr = CFDataGetBytePtr(data),
            let colorSpaceModel = cgImage.colorSpace?.model,
            let componentLayout = cgImage.bitmapInfo.componentLayout
        else {
            assertionFailure("Could not get the color of a pixel in an image")
            return .clear
        }
        
        assert(
            colorSpaceModel == .rgb,
            "The only supported color space model is RGB")
        assert(
            cgImage.bitsPerPixel == 32 || cgImage.bitsPerPixel == 24,
            "A pixel is expected to be either 4 or 3 bytes in size")
        
        let bytesPerRow = cgImage.bytesPerRow
        let bytesPerPixel = cgImage.bitsPerPixel/8
        let pixelOffset = Int(y)*bytesPerRow + Int(x)*bytesPerPixel
        
        if componentLayout.count == 4 {
            let components = (
                dataPtr[pixelOffset + 0],
                dataPtr[pixelOffset + 1],
                dataPtr[pixelOffset + 2],
                dataPtr[pixelOffset + 3]
            )
            
            var alpha: UInt8 = 0
            var red: UInt8 = 0
            var green: UInt8 = 0
            var blue: UInt8 = 0
            
            switch componentLayout {
            case .bgra:
                alpha = components.3
                red = components.2
                green = components.1
                blue = components.0
            case .abgr:
                alpha = components.0
                red = components.3
                green = components.2
                blue = components.1
            case .argb:
                alpha = components.0
                red = components.1
                green = components.2
                blue = components.3
            case .rgba:
                alpha = components.3
                red = components.0
                green = components.1
                blue = components.2
            default:
                return .clear
            }
            
            if cgImage.bitmapInfo.chromaIsPremultipliedByAlpha && alpha != 0 {
                let invUnitAlpha = 255/CGFloat(alpha)
                red = UInt8((CGFloat(red)*invUnitAlpha).rounded())
                green = UInt8((CGFloat(green)*invUnitAlpha).rounded())
                blue = UInt8((CGFloat(blue)*invUnitAlpha).rounded())
            }
            
            return .init(red: red, green: green, blue: blue, alpha: alpha)
            
        } else if componentLayout.count == 3 {
            let components = (
                dataPtr[pixelOffset + 0],
                dataPtr[pixelOffset + 1],
                dataPtr[pixelOffset + 2]
            )
            
            var red: UInt8 = 0
            var green: UInt8 = 0
            var blue: UInt8 = 0
            
            switch componentLayout {
            case .bgr:
                red = components.2
                green = components.1
                blue = components.0
            case .rgb:
                red = components.0
                green = components.1
                blue = components.2
            default:
                return .clear
            }
            
            return .init(red: red, green: green, blue: blue, alpha: UInt8(255))
            
        } else {
            assertionFailure("Unsupported number of pixel components")
            return .clear
        }
    }*/
    
}

extension CGBitmapInfo {
    
    enum ComponentLayout {
        
        case bgra
        case abgr
        case argb
        case rgba
        case bgr
        case rgb
        
        var count: Int {
            switch self {
            case .bgr, .rgb: return 3
            default: return 4
            }
        }
        
    }
    
    var componentLayout: ComponentLayout? {
        guard let alphaInfo = CGImageAlphaInfo(rawValue: rawValue & Self.alphaInfoMask.rawValue) else { return nil }
        let isLittleEndian = contains(.byteOrder32Little)
        
        if alphaInfo == .none {
            return isLittleEndian ? .bgr : .rgb
        }
        let alphaIsFirst = alphaInfo == .premultipliedFirst || alphaInfo == .first || alphaInfo == .noneSkipFirst
        
        if isLittleEndian {
            return alphaIsFirst ? .bgra : .abgr
        } else {
            return alphaIsFirst ? .argb : .rgba
        }
    }
    
    var chromaIsPremultipliedByAlpha: Bool {
        let alphaInfo = CGImageAlphaInfo(rawValue: rawValue & Self.alphaInfoMask.rawValue)
        return alphaInfo == .premultipliedFirst || alphaInfo == .premultipliedLast
    }
}
