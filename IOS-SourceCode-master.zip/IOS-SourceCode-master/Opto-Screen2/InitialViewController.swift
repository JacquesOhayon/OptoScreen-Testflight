//
//  InitialViewController.swift
//  Opto-Screen2
//
//  Created by apple on 1/17/22.
//

import UIKit
import Purchases

class InitialViewController: UIViewController {
    
    @IBOutlet var contentLabel: UILabel!
    @IBOutlet var purchaseDateLabel: UILabel!
    @IBOutlet var expirationDateLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        Purchases.shared.purchaserInfo { (purchaserInfo, error) in
            if let e = error {
                print(e.localizedDescription)
            }
            
            if purchaserInfo?.entitlements["OptoScreen2 iOS"]?.isActive == true {
                if #available(iOS 13.0, *) {
                    self.purchaseDateLabel.textColor = UIColor.label
                    self.expirationDateLabel.textColor = UIColor.label
                } else {
                    self.purchaseDateLabel.textColor = UIColor.systemGray
                    self.expirationDateLabel.textColor = UIColor.systemGray
                }
                
                let dateFormatter = DateFormatter()
                dateFormatter.dateStyle = .medium
                
                if let purchaseDate = purchaserInfo?.purchaseDate(forEntitlement: "OptoScreen2 iOS") {
                    self.purchaseDateLabel.text = "Purchase Date: \(dateFormatter.string(from: purchaseDate))"
                }
                if let expirationDate = purchaserInfo?.expirationDate(forEntitlement: "OptoScreen2 iOS") {
                    self.expirationDateLabel.text = "Expiration Date: \(dateFormatter.string(from: expirationDate))"
                }
                
            } else {
                let controller = PaywallViewController(
                    termsOfServiceUrlString: "https://visualintelligence.us/terms-of-service/",
                    privacyPolicyUrlString: "https://visualintelligence.us/privacy-policy/")
                
                controller.titleLabel.text = "Welcome to Opto-Screen"
                controller.subtitleLabel.text = "We provide optical diagnostic information and artificial intelligence for physicians and more!"
                controller.modalPresentationStyle = .fullScreen
                self.present(controller, animated: true, completion: nil)
            }
        }
    }
    
}
