//
//  CropperViewController.swift
//  Opto-Screen2
//
//  Created by apple on 11/7/21.
//

import UIKit
import CoreImage
import AKImageCropperView

protocol CropperViewControllerDelegate {
    func croppedImage(image: UIImage)
}

class CropperViewController: UIViewController, AKImageCropperViewDelegate {
    
    @IBOutlet var cropView: AKImageCropperView!
    
    var image: UIImage!
    
    var processedImage: UIImage!
    var delegate: CropperViewControllerDelegate!
    var angle: Double = 0.0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        cropView.image = image
        cropView.delegate = self
    }
    
    func imageCropperViewDidChangeCropRect(view: AKImageCropperView, cropRect rect: CGRect) {
        print(view)
    }
    
    @IBAction func backBtnAction(_ sender: UIButton) {
        guard !cropView.isEdited
        else { let alert = UIAlertController(title: "Warning!",
                                             message: "All changes will be lost.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Yes", style: .cancel, handler: { _ in
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                    self.dismiss(animated: true, completion: nil)
                }}))
            alert.addAction(UIAlertAction(title: "No", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            return
        }
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    @IBAction func rotateBtnAction(_ sender: UIButton) {
        angle += Double.pi/2
        cropView.rotate(angle, withDuration: 0.3, completion: { _ in
            if self.angle >= (2 * Double.pi) {
                self.angle = 0.0
            }
        })
    }
    
    @IBAction func cropBtnAction(_ sender: UIButton) {
        guard let image = cropView.croppedImage else { return }
        let alert = UIAlertController(title: "Save", message: "Do you Want to Save This Image?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Yes", style: .default, handler: { _ in
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.dismiss(animated: true, completion: nil)
            }
        }))
        alert.addAction(UIAlertAction(title: "No", style: .cancel, handler: { _ in
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                self.dismiss(animated: true, completion: nil)
            }
            
        }))
        self.present(alert, animated: true, completion: nil)
        delegate.croppedImage(image: image)
    }
    
    @IBAction func resetBtnAction(_ sender: UIButton) {
        if self.image != nil {
            cropView.image = image
        }
    }
}
