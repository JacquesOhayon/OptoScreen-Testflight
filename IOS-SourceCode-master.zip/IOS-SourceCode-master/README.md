#  Version Control and Updates
Version: FALL 2023 bug fixed
    
	*Fixed memory issue caused by getPixelInfo using deallocate
    	*Fixed OUT OF BOUND pixels coordinates for (x,y).
	#Fixed all crashes and bugs for image selection
12/08/2023


    
    

