//
//  EyePixelObjectView.swift
//  Opto-Screen2
//
//  Created by apple on 10/30/21.
//

import UIKit

class EyePixelObjectView: UIView {
    
    var path: UIBezierPath!
    var path2: UIBezierPath!
    let color = UIColor.blue
    var width: CGFloat!
    var height: CGFloat!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = .clear
        width = self.frame.size.width
        height = self.frame.size.height
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func drawSquare() {
        path = UIBezierPath()
        path.move(to: CGPoint(x: 0.0, y: 0.0))
        path.addLine(to: CGPoint(x: 0.0, y: height))
        path.addLine(to: CGPoint(x: width, y: height))
        path.addLine(to: CGPoint(x: width, y: 0.0))
        path.lineWidth = 2
        path.close()
        UIColor.clear.setFill()
        path.fill()
        color.setStroke()
        path.stroke()
    }
    
    func drawCircle() {
        path2 = UIBezierPath(ovalIn: CGRect(x: (width/2 - height/2), y: 0.0, width: height, height: height))
        color.setStroke()
        path2.lineWidth = 2
        path2.stroke()
    }
    
    override func draw(_ rect: CGRect) {
        drawSquare()
        drawCircle()
    }
    
}
